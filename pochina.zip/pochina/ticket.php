<?php
// Memuat autoload dari Composer
require 'vendor/autoload.php';

// Gunakan namespace dari library
use Endroid\QrCode\QrCode;
use Endroid\QrCode\Writer\PngWriter;
use Endroid\QrCode\Encoding\Encoding;
use Endroid\QrCode\ErrorCorrectionLevel\ErrorCorrectionLevelL;

// Membuat instance QR Code dengan teks yang ingin dimasukkan
$qrCode = new QrCode('https://www.example.com');
$qrCode->setEncoding(Encoding::UTF_8)   // Set encoding QR Code
       ->setErrorCorrectionLevel(new ErrorCorrectionLevelL())  // Set error correction level
       ->setSize(300)  // Set ukuran QR Code
       ->setMargin(10); // Set margin QR Code

// Tentukan lokasi penyimpanan file QR code
$filePath = 'uploads/qrcodes/qrcode.png'; // Lokasi file yang disimpan di folder 'uploads/qrcodes'

// Gunakan writer untuk menghasilkan gambar PNG
$writer = new PngWriter();

// Menyimpan QR Code ke file di folder 'uploads/qrcodes'
$writer->writeFile($qrCode, $filePath);  // Menyimpan file QR Code sebagai 'qrcode.png'

// Memberikan informasi bahwa file sudah disimpan
echo "QR Code berhasil disimpan di: " . $filePath;

// Jika ingin menampilkan QR Code langsung di browser
// header('Content-Type: image/png');
// echo $writer->writeString($qrCode);  // Menampilkan QR Code dalam format PNG
?>
